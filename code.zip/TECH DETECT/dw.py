import mysql.connector


mainUser = "Will Varner"
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="Oatmeal_007",
  database="techdetect"
)

mycursor = mydb.cursor()

mycursor.execute("SELECT studentID FROM students WHERE studentName = '"+mainUser+"'")

ID = mycursor.fetchall()

mainStudentID = str(ID)
print(mainStudentID)



#the code:

mainStudentID = mainStudentID[2:7]
print(mainStudentID)