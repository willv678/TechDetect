This is a pre release of TechDetect, a python opencv-powered facial detection check in app
MYSQL SERVER IS REQUIRED, setup info not included
To start:

 - Check requirements.txt for reqs or run *pip install -r requirements.txt*
 - In the createData.py file
	- Answer login prompts
	- Enter new user info, including full name and an ID
	- App will run for ~5 seconds, taking photos and uploading them

 - Run techDetect.py
	- Answer login prompts

Enjoy!