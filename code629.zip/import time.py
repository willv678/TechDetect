import time

print("Hello")
time.sleep(2)
print("It's time")