import mysql.connector

mydb = mysql.connector.connect(
	host = "localhost",
	user = "root",
	password = "Oatmeal_007",
    database="python"
)

print(mydb)

mycursor = mydb.cursor()

mycursor.execute("ALTER TABLE attendance ADD COLUMN timeIn time")