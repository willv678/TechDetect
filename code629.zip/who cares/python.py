
from datetime import datetime
import time


time1 = "uh oh"

with time1:
    def refreshTime():
        myobj = datetime.now()
        hour = myobj.hour
        minute = myobj.minute
        second = myobj.second
        time1 = str(hour) + ":" + str(minute) + ":" + str(second)



print("The time is", time1)
print("\n in 5 seconds the time is gonna be: \n")
time.sleep(5)
refreshTime()
print(time1)






""""
# printing current hour using hour
# class
print("Current hour ", myobj.hour)

# printing current minute using minute
# class
print("Current minute ", myobj.minute)

# printing current second using second
# class
print("Current second ", myobj.second)

# printing current microsecond using
# microsecond class
print("Current microsecond ", myobj.microsecond)



time = (myobj.hour,myobj.minute,myobj.second)

print("\n")
print(time)
print(myobj.hour,myobj.minute,myobj.second, sep=":")



print(time1)
"""