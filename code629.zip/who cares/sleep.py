import time


print("Hello I am going to wait 5 seconds")

time.sleep(5)

print("It has been 5 seconds")